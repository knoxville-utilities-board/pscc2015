Install Node and NPM

Install git on your machine.
	http://msysgit.github.io/
	Once installed, because the git:// port is blocked on the firewall, we need to route git:// to https://
		git config --global url."https://".insteadOf git://

If you currently do not have grunt or bower, install them now:
	npm install -g bower
	npm install -g grunt

npm install
bower install
grunt slurp