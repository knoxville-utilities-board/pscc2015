/*global module:false*/
module.exports = function (grunt) {
  grunt.initConfig({
    esri_slurp: {
      dev: {
        options: {
          version: '3.12',
          packageLocation: 'src/esri',
          beautify: true
        },
        dest: "src/esri"
      }
    },
    clean: ['release'],
    dojo: {
      dist: {
        options: {
          profile: 'release.profile.js', // Profile for build
        }
      },
      options: {
        dojo: 'src/dojo/dojo.js', // Path to dojo.js file in dojo source
        load: 'build', // Optional: Utility to bootstrap (Default: 'build')
        // profiles: [], // Optional: Array of Profiles for build
        // appConfigFile: '', // Optional: Config file for dojox/app
        // package: '', // Optional: Location to search package.json (Default: nothing)
        // packages: [], // Optional: Array of locations of package.json (Default: nothing)
        // require: '', // Optional: Module to require for the build (Default: nothing)
        // requires: [], // Optional: Array of modules to require for the build (Default: nothing)
        releaseDir: '../release', // Optional: release dir rel to basePath (Default: 'release')
        cwd: './', // Directory to execute build within
        // dojoConfig: '', // Optional: Location of dojoConfig (Default: null),
        // Optional: Base Path to pass at the command line
        // Takes precedence over other basePaths
        // Default: null
        basePath: './src'
      }
    }
  });

  grunt.loadNpmTasks('grunt-esri-slurp');
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-dojo');

  grunt.registerTask('slurp', ['esri_slurp:dev']);
  grunt.registerTask('build', ['clean', 'slurp', 'dojo']);
};
