define({
		status: "${start} - ${end} z ${total} výsledkov",
		gotoFirst: "Prvá stránka",
		gotoNext: "Nasledovná stránka",
		gotoPrev: "Predchádzajúca stránka",
		gotoLast: "Posledná stránka",
		gotoPage: "Na stránku",
		jumpPage: "Na stránku"
});
