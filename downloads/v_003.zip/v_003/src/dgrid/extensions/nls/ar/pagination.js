define({
	status: "${start} - ${end} من ${total} نتائج",
	gotoFirst: "الصفحة الأولى",
	gotoNext: "التالي",
	gotoPrev: "السابق",
	gotoLast: "الصفحة الأخيرة",
	gotoPage: "صفحة",
	jumpPage: "إذهب لصفحة "	
});
