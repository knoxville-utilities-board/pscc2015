define(
({
	invalidMessage: "De opgegeven waarde is ongeldig.",
	missingMessage: "Deze waarde is verplicht.",
	rangeMessage: "Deze waarde is niet toegestaan."
})
);
