define(
({
	previousMessage: "Pilihan sebelumnya",
	nextMessage: "Pilihan lain"
})
);

