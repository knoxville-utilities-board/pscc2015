define(
({
	fontSize: "Koko",
	fontName: "Fontti",
	formatBlock: "Muotoile",
	serif: "serif",
	"sans-serif": "sans-serif",
	monospace: "monospace",
	cursive: "cursive",
	fantasy: "fantasy",
	noFormat: "Ei mitään",
	p: "Kappale",
	h1: "Otsikko",
	h2: "Alatason otsikko",
	h3: "Alimman tason otsikko",
	pre: "Esimuotoiltu",
	1: "xx-small",
	2: "x-small",
	3: "small",
	4: "medium",
	5: "large",
	6: "x-large",
	7: "xx-large"
})
);
